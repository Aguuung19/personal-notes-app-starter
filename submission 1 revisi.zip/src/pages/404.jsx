import React from "react";

function InvalidURl() {
    return (
        <p>404 not found</p>
    );
}

export default InvalidURl;